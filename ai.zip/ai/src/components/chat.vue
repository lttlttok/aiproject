<script setup>

</script>

<template>
 <div>对话</div>
</template>

<style scoped>

</style>
