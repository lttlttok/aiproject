<script setup>
import { ref, defineEmits, getCurrentInstance } from 'vue'
const instance = getCurrentInstance()

const emit = defineEmits(["sendMsg"]);
const small = ref(true)
const message = ref('')
const message1 = ref('')
const handlePdf = () =>{
  small.value = !small.value
}
const send = ()=>{
  emit('sendMsg')
  if (instance) {  
    instance.proxy.$mitt.emit('refreshLeft', message1.value);
    message1.value = ''  
  }
}
</script>

<template>
  <div>
    <div class="tag">
      <el-tag @click="handlePdf">pdf</el-tag>
    </div>
    <el-input v-if="small" v-model="message"></el-input>
  <div v-else class="box">
    <el-input  v-model="message1"></el-input>
    <el-button @click="send">发送</el-button>
  </div>
  </div>
 
</template>

<style scoped>
.box{
  width: 100%;
  height: 300px;
  border: 1px solid blue;
}
</style>
