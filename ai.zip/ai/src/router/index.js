import { createRouter, createWebHashHistory } from 'vue-router'
import layout from '../layout/index.vue'

const routes = [
    {
        path: '/',
        name: 'Layout',
        component: layout,
        children: [
            {
                path: '',
                name: 'home',
                component:() => import('../view/home/index.vue')
            }
        ],
      
    }
]

const router = createRouter({
    history: createWebHashHistory(),
    routes 
})

export default router