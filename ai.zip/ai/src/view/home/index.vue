<template>
<welcome v-if="newChat"/>
<chat v-else/>
<sendMessage @sendMsg="sendMsg"/>

</template>

<script setup>
import welcome from '../../components/welcome.vue';
import chat from '../../components/chat.vue';
import sendMessage from '../../components/sendMessage.vue';
import { ref } from 'vue';
import { getCurrentInstance } from 'vue'
const newChat = ref(true)
const instance = getCurrentInstance()
if (instance) {  
    instance.proxy.$mitt.on('newChat', ()=>{
        newChat.value = false
    });  
}  
const sendMsg= ()=>{
    newChat.value = false
}
</script>