<template>
    <div class="common-layout">
      <el-container>
        <el-aside width="200px"><LeftMenu></LeftMenu></el-aside>
        <el-main><router-view></router-view></el-main>
      </el-container>
    </div>
</template> 

<script setup>
import LeftMenu from './components/LeftMenu.vue';


</script>