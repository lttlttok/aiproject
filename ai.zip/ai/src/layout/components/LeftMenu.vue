<script setup>
import { getCurrentInstance, reactive, onMounted,ref } from 'vue'
const instance = getCurrentInstance()
const handleNewChatClick = () =>{
  if (instance) {  
    instance.proxy.$mitt.emit('newChat') 
  }  
}
const list = ref([])
const init = () => {
  setTimeout(() => {
    list.value = ['1']
  }, 100);
}
onMounted(()=>{
  init()
})

if (instance) {  
    instance.proxy.$mitt.on('refreshLeft', (msg)=>{
      // init()
      list.value.push(msg)
    });  
} 
</script>

<template>
  <el-button type="primary" @click="handleNewChatClick">新对话</el-button>
  <ul v-if="list.length>0">
    <li v-for="(item, index) in list" :key="index">{{ item }}</li>
  </ul>
  <el-button type="primary">登录</el-button>
</template>

<style scoped>

</style>
